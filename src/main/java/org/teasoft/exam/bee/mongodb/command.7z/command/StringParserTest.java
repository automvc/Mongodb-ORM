package org.teasoft.exam.bee.mongodb.command;

import org.teasoft.beex.mongodb.StringParser;

public class StringParserTest {
	
	public static void main(String[] args) {
		String filter="{ \"birthday\" : { \"$gte\" : { \"$date\" : \"2018-01-20T16:00:00.000Z\"}}}";
//		String filter="{ \"birthday\",\"   : { \"$gte\" : { \"$date\" : \"2018-01-20T16:00:00.000Z\"}}}\"";//在引号内不行
		
		StringBuffer sb=new StringBuffer(filter);
		
		System.out.println(filter);
		
		String target=": { \"$date\" : ";
		int a=	StringParser.getKeyPosition(filter, target);
//		int a=	StringTest4.getKeyPosition(filter, ": { \"$gte\" : { \"",15); //从指定位置开始，可以避开开始的引号
		
		System.out.println(a);
		
		
		int  b=	StringParser.getKeyPosition(filter.substring(a), "}");
		System.out.println(b);
		
		sb.replace(a+b, a+b+1, ")"); 
		sb.replace(a, a+target.length(), ": ISODate(");
		
		System.out.println(sb.toString());
	}
	
	
	private void tranferDate(StringBuffer sb) {
		String filter = sb.toString();
		String target = ": { \"$date\" : ";
		int a = StringParser.getKeyPosition(filter, target);
		int b = StringParser.getKeyPosition(filter.substring(a), "}");
		sb.replace(a + b, a + b + 1, ")");
		sb.replace(a, a + target.length(), ": ISODate(");
	}

}
