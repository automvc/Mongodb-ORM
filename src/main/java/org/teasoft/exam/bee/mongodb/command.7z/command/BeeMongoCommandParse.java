package org.teasoft.exam.bee.mongodb.command;

import java.util.Arrays;
import java.util.List;

import org.bson.Document;
import org.teasoft.honey.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

//从Parse2复制
//用fastjson插入已可以
public class BeeMongoCommandParse {
	
	//还有带点的表名 point.test   要转成找到第一个左括号,再倒推  TODO
//	db.point.test.insert({"address" : "南京 禄口国际机场","loc" : { "type": "Point", "coordinates": [118.783799,31.979234]}})  
//	db.point.test.insert({"address" : "南京 浦口公园","loc" : { "type": "Point", "coordinates": [118.639523,32.070078]}})  
//	db.point.test.insert({"address" : "南京 火车站","loc" : { "type": "Point", "coordinates": [118.803032,32.09248]}})  
//	db.point.test.insert({"address" : "南京 新街口","loc" : { "type": "Point", "coordinates": [118.790611,32.047616]}})  
//	db.point.test.insert({"address" : "南京 张府园","loc" : { "type": "Point", "coordinates": [118.790427,32.03722]}})  
//	db.point.test.insert({"address" : "南京 三山街","loc" : { "type": "Point", "coordinates": [118.788135,32.029064]}})  
//	db.point.test.insert({"address" : "南京 中华门","loc" : { "type": "Point", "coordinates": [118.781161,32.013023]}})  
//	db.point.test.insert({"address" : "南京 安德门","loc" : { "type": "Point", "coordinates": [118.768964,31.99646]}})
//	原文链接：https://blog.csdn.net/jack85986370/article/details/51889459

	public static void main(String[] args) {
//		doSuid(CommandString.find0);
//		doSuid(CommandString.insertOne); //{"n": 1, "ok": 1.0}
//		doSuid(CommandString.insertMany); //{"n": 2, "ok": 1.0}
		
		
		
//		doSuid(CommandString.deleteOne); //{"n": 0, "ok": 1.0}
//		doSuid(CommandString.deleteOne_2);  //
//		doSuid(CommandString.deleteOne_3);  //{"n": 1, "ok": 1.0}
//		doSuid(CommandString.deleteOne_4);  //{"n": 1, "ok": 1.0}  多个符合也是删一个
//		doSuid(CommandString.deleteMany);   //{"n": 4, "ok": 1.0}
//		doSuid(CommandString.delete_Old);    //{"n": 2, "ok": 1.0}
		
//		doSuid(CommandString.deleteAll);  //{"n": 7, "ok": 1.0}
		
//		doSuid(CommandString.deleteAll21);  //{"n": 10, "ok": 1.0}
		
		
//		doSuid(CommandString.insertMany21); //{"n": 10, "ok": 1.0}
//		doSuid(CommandString.updateOne21);  //{"n": 1, "nModified": 1, "ok": 1.0}
//		doSuid(CommandString.updateMany21);  //{"n": 3, "nModified": 3, "ok": 1.0}
		//更新操作时，获取受影响的行，应取nModified。
		
//		update.n
//		The number of documents selected for update. 
//		update.nModified
//		The number of documents updated. If the update operation results in no change to the document,
//		such as setting the value of the field to its current value, 
//		nModified can be less than n.
		
//		doSuid(CommandString.replaceOne21);
		
//	插入时：	{"n": 1, "upserted": [{"index": 0, "_id": {"$oid": "63dcbd1d28f119217ddee8c5"}}], "nModified": 0, "ok": 1.0}
		//upserted不为null,取null; 否则取
//		还是用这个：取nModified，为null,才取n
		doSuid(CommandString.save21); //更新时：{"n": 1, "nModified": 1, "ok": 1.0}
		
		

		String findStr[] = new String[14];
		findStr[0] = CommandString.find0;
		findStr[1] = CommandString.find1;
		findStr[2] = CommandString.find2;
		findStr[3] = CommandString.find3;
		findStr[4] = CommandString.find4;
		findStr[5] = CommandString.find5;
		findStr[6] = CommandString.find6;
		findStr[7] = CommandString.find7;
		findStr[8] = CommandString.find8;
		findStr[9] = CommandString.find9;
		findStr[10] = CommandString.find10;
		findStr[11] = CommandString.find11;
		findStr[12] = CommandString.find12;
		findStr[13] = CommandString.find13;
		for (int i = 0; i < findStr.length; i++) {
			if (findStr[i] == null)
				System.err.println("--------------:" + i);
			
			if (i == 12) { // TODO 5
//				doSuid(findStr[i]);
			}
		}
	}

	// eg:"db.movies.find()";
	public static void doSuid(String str) {
		
		System.out.println(str);
		
//		String str=CommandString.find0;
//		db.movies.find( { "title": "Tag" } ).limit(1).sort({"runtime":1}).skip(1)
		str = str.trim();
		if (str.endsWith(";"))
			str = str.substring(0, str.length() - 1);

		if (str != null && str.startsWith("db."))
			System.out.println("start with: db.");

		int index1 = str.indexOf('.');
		int index2 = str.indexOf('.', index1 + 1);

//		System.out.println(str);
//		System.out.println(index1);
//		System.out.println(index2);

		String tableName = str.substring(index1 + 1, index2).trim();
		System.out.println(tableName); // movies
		// TODO db.getCollection('movies') 还要处理这种语法

		int index3 = str.indexOf('(', index2 + 1);
		String type = str.substring(index2 + 1, index3).trim();
		System.out.println("type:" + type);

//		String inputJson=str.substring(index3+1, str.length()-1).trim();
		String inputJson = str.substring(index3, str.length()).trim();

		System.out.println("类型后的：" + inputJson);

		inputJson = inputJson.trim();

		BeeMongoCommandParse p = new BeeMongoCommandParse();
		String r = "None";
		if ("find".equals(type) || "findOne".equals(type)) {
			r = p.find(tableName, inputJson);
			
			
		} else if ("insertOne".equals(type) || "insertMany".equals(type)) {
			r = p.insert(tableName, inputJson);
			
			
		}else if ("deleteOne".equals(type)) {
			r = p.delete(tableName, inputJson, true);
		}else if ("deleteMany".equals(type) || "remove".equals(type)) {
			r = p.delete(tableName, inputJson, false);
			
//		replaceOne在navicat的行为与调用命令的不一样；调用命令可插入，但navicat不行。	
		}else if ("updateOne".equals(type)){
			r = p.update(tableName, inputJson, false);
		} else if ("updateMany".equals(type)) {
			r = p.update(tableName, inputJson, true);
		} else if ("replaceOne".equals(type) || "save".equals(type)) {
			r = p.update(tableName, inputJson, true, true);
		}
		

		System.err.println(r);
	}

	public String find(String tableName, String inputJson) {

		int pos = StringTest4.getEndPosition(inputJson); // 查找{(开头，} )结束的下标位置
		System.out.println(inputJson);
		System.out.println(pos);

		Document doc = new Document();
		doc.append("find", tableName);

		if (pos > 0) {
//		str.substring(1,pos).trim()
			String findJson = inputJson.substring(1, pos).trim();
			System.out.println("findJson(before):" + findJson);

			String selectColumn = "";

//		int projIndex=StringTest4.getKeyEndPosition(filterJson, "},{");
			int filterEndIndex = StringTest4.getKeyEndPosition2(findJson, '{', '}');

			System.out.println("--filterEndIndex:" + filterEndIndex);
			System.out.println("--findJson length:" + findJson.length());
			String filterJson;
			if (findJson.length() > filterEndIndex + 1) {
				String newFilter = findJson.substring(0, filterEndIndex + 1);
				System.out.println("--newFilter:" + newFilter);

				selectColumn = findJson.substring(filterEndIndex + 1).trim().substring(1).trim();
				System.out.println("--selectColumn:" + selectColumn);

				filterJson = newFilter;
			} else {
				filterJson = findJson;
			}

			System.out.println("--filter:" + filterJson);

			// if(pos<inputJson.length
			String others = inputJson.substring(pos + 1, inputJson.length());
			System.out.println("--others:" + others);

			String limitPara = "";
			String sortPara = "";
			String skipPara = "";

			if (StringUtils.isNotBlank(others)) {
//		.limit(1).sort({"runtime":1}).skip(1)
				int limitIndex = StringTest4.getKeyPosition(others, "limit(");
				int sortIndex = StringTest4.getKeyPosition(others, "sort(");
				int skipIndex = StringTest4.getKeyPosition(others, "skip(");

				System.out.println("limitIndex: " + limitIndex);
				System.out.println("sortIndex: " + sortIndex);
				System.out.println("skipIndex: " + skipIndex);

				if (limitIndex > 0)
					System.out.println("limitIndex subString: " + others.substring(limitIndex + 6));
				if (sortIndex > 0)
					System.out.println("sortIndex subString: " + others.substring(sortIndex + 5));
				if (skipIndex > 0)
					System.out.println("skipIndex subString: " + others.substring(skipIndex + 5));

//		System.out.println("limitIndex subString: "+StringTest4.getKeyPosition(others.substring(limitIndex+6),")"));
//		System.out.println("sortIndex subString: "+StringTest4.getKeyPosition(others.substring(sortIndex+5),")"));
//		System.out.println("skipIndex subString: "+StringTest4.getKeyPosition(others.substring(skipIndex+5),")"));

				if (limitIndex > 0) {
					String limitOthers = others.substring(limitIndex + 6);
					limitPara = limitOthers.substring(0, StringTest4.getKeyPosition(limitOthers, ")"));
				}

				if (sortIndex > 0) {
					String sortOthers = others.substring(sortIndex + 5);
					sortPara = sortOthers.substring(0, StringTest4.getKeyPosition(sortOthers, ")"));
				}

				if (skipIndex > 0) {
					String skipOthers = others.substring(skipIndex + 5);
					skipPara = skipOthers.substring(0, StringTest4.getKeyPosition(skipOthers, ")"));
				}

				System.out.println("limit para: " + limitPara);
				System.out.println("sort para: " + sortPara);
				System.out.println("skip para: " + skipPara);
			}

			if ("".equals(inputJson)) {
				// empty
			} else {
				Document filter = Document.parse(filterJson);
				doc.append("filter", filter);

				if (StringUtils.isNotBlank(selectColumn)) {
					Document projection = Document.parse(selectColumn);
					doc.append("projection", projection);
				}

//			执行的顺序是先 sort(), 然后是 skip()，最后是显示的 limit()。
				if (StringUtils.isNotBlank(sortPara)) {
					Document sortDoc = Document.parse(sortPara);
					doc.append("sort", sortDoc);
				}

				if (StringUtils.isNotBlank(skipPara)) {
					doc.put("skip", Integer.parseInt(skipPara.trim()));
				}

				if (StringUtils.isNotBlank(limitPara)) {
					doc.put("limit", Integer.parseInt(limitPara.trim()));
				}
			}

		}
		System.out.println(doc.toJson());
		Document result = getDb().runCommand(doc);

		return result.toJson();
	}

	public String insert(String tableName, String inputJson) {
		Document doc = new Document();
		doc.append("insert", tableName);
		String para = inputJson.substring(1, inputJson.length() - 1);
		List<Document> list = JSONObject.parseArray(para, Document.class);// 把字符串数组转换成List
		doc.append("documents", list);
		Document result = getDb().runCommand(doc);
		return result.toJson();
	}
	
//	db.runCommand(
//		    {
//		      delete: <collection>,
//		      deletes: [
//		         {
//		           q : <query>,
//		           limit : <integer>,
//		           collation: <document>,
//		           hint: <document|string>
//		         },
//		         ...
//		      ],
//		      comment: <any>,
//		      let: <document>, // Added in MongoDB 5.0
//		      ordered: <boolean>,
//		      writeConcern: { <write concern> }
//		   }
//		)
	public String delete(String tableName, String inputJson,boolean isDelOne) {
		Document doc = new Document();
		doc.append("delete", tableName);
		
		String para = inputJson.substring(1, inputJson.length() - 1);
		System.out.println("delete para: " + para);
		
		if("{}".equals(para.replace(" ",""))) {
			System.err.println("will delete all !");
		}
		//可在此处拦截，不给删除所有
		
		Document filter = new Document();
		Document queryDoc = Document.parse(para);
		filter.append("q", queryDoc);
		int delFlag=isDelOne?1:0;
		filter.append("limit", delFlag);
		doc.append("deletes", Arrays.asList(filter));
		
		
		Document result = getDb().runCommand(doc);
		return result.toJson();
	}
	
	public String update(String tableName, String inputJson, boolean isMulit) {
		return update(tableName, inputJson, isMulit,false);
	}
	
	public String update(String tableName, String inputJson, boolean isMulit,boolean isUpdateOrInsert) {
		Document doc = new Document();
		doc.append("update", tableName);

		int pos = StringTest4.getEndPosition(inputJson); // 查找{(开头，} )结束的结束下标位置
		System.out.println(inputJson);
		System.out.println(pos);

		if (pos > 0) {
			String findJson = inputJson.substring(1, pos).trim();
			System.out.println("findJson(before):" + findJson);

			String setPart = "";
			int filterEndIndex = StringTest4.getKeyEndPosition2(findJson, '{', '}');

			System.out.println("--filterEndIndex:" + filterEndIndex);
			System.out.println("--findJson length:" + findJson.length());
			String filterJson = "";
			if (findJson.length() > filterEndIndex + 1) {
				String newFilter = findJson.substring(0, filterEndIndex + 1);
				System.out.println("--newFilter:" + newFilter);

				setPart = findJson.substring(filterEndIndex + 1).trim().substring(1).trim();
				System.out.println("--setPart:" + setPart);

				filterJson = newFilter;
			}else {
				System.out.println("update 必须指明set部分");
			}

			Document oneUpdate = new Document();
			oneUpdate.append("q", Document.parse(filterJson));
			oneUpdate.append("u", Document.parse(setPart));
			oneUpdate.append("multi", isMulit);
			oneUpdate.append("upsert", isUpdateOrInsert); //
			doc.append("updates", Arrays.asList(oneUpdate));
		}else {
			System.out.println("update 必须 有参数");
		}
		
		Document result = getDb().runCommand(doc);
		return result.toJson();
	}
	
	
	private MongoDatabase getDb() {
		MongoClient mongoClient = null;
		MongoDatabase mongoDatabase = null;
		try {
			mongoClient = MongoClients.create("mongodb://localhost:27017");
			mongoDatabase = mongoClient.getDatabase("testa");

//	          CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(
//	                  MongoClientSettings.getDefaultCodecRegistry(),
//	                  CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));
//	          mongoDatabase.withCodecRegistry(pojoCodecRegistry);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
//	    	 if(mongoClient!=null) mongoClient.close();
		}

		return mongoDatabase;
	}
	
	

}
