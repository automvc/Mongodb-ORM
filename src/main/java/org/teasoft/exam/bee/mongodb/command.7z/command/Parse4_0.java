package org.teasoft.exam.bee.mongodb.command;
import java.util.Map;

import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.teasoft.honey.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Parse4_0 {
	
	public static void main(String[] args) {
//		doSuid(CommandString.find0);
//		doSuid(CommandString.insertOne);
//		doSuid(CommandString.insertMany);
////		doSuid(CommandString.find2);
		
		String findStr[]=new String[11];
		findStr[0]=CommandString.find0;
		findStr[1]=CommandString.find1;
		findStr[2]=CommandString.find2;
		findStr[3]=CommandString.find3;
		findStr[4]=CommandString.find4;
		findStr[5]=CommandString.find5;
		findStr[6]=CommandString.find6;
		findStr[7]=CommandString.find7;
		findStr[8]=CommandString.find8;
		findStr[9]=CommandString.find9;
		findStr[10]=CommandString.find10;
		for (int i = 0; i < findStr.length; i++) {
			if(findStr[i]==null) System.err.println("--------------:"+i);
			if(i==1) { //TODO 5
				System.out.println(findStr[i]);
				doSuid(findStr[i]);
			}
		}
	}
	
	//eg:"db.movies.find()";
	public static void doSuid(String str) {
//		String str=CommandString.find0;
//		db.movies.find( { "title": "Tag" } ).limit(1).sort({"runtime":1}).skip(1)
		str=str.trim();
		if(str.endsWith(";")) str=str.substring(0,str.length()-1);
		
		if(str!=null && str.startsWith("db."))
		  System.out.println("start with: db.");
		
		
		int index1=str.indexOf('.');
		int index2=str.indexOf('.',index1+1);
		
		
//		System.out.println(str);
//		System.out.println(index1);
//		System.out.println(index2);
		
		String tableName=str.substring(index1+1, index2).trim();
		System.out.println(tableName); //movies
		//TODO db.getCollection('movies')  还要处理这种语法
		
		int index3=str.indexOf('(',index2+1);
		String type=str.substring(index2+1, index3).trim();
		System.out.println("type:"+type);
		
		
//		String inputJson=str.substring(index3+1, str.length()-1).trim();
		String inputJson=str.substring(index3, str.length()).trim();
		
		System.out.println("类型后的："+inputJson);
		
		inputJson=inputJson.trim();
		
		Parse4_0 p=new Parse4_0();
		String r="None";
		if("find".equals(type) || "findOne".equals(type)) {
			r=p.find(tableName, inputJson);
		}else if("insertOne".equals(type) || "insertMany".equals(type)) {
			r=p.insert(tableName, inputJson);
		}
		
		System.err.println(r);
	}
	
	public String find(String tableName,String inputJson) {
		
		
		int pos=StringTest4.getEndPosition(inputJson);
		System.out.println(inputJson);
		System.out.println(pos);
		
//		str.substring(1,pos).trim()
		String filterJson=inputJson.substring(1,pos).trim();
		System.out.println("findJson(before):"+filterJson);
		
		int projIndex=StringTest4.getKeyEndPosition(filterJson, "},{");
		System.out.println("--projIndex:"+projIndex);
		String selectColumn="";
		if(projIndex>0) {
			String newFilter=filterJson.substring(0,projIndex+1);
			System.out.println("--newFilter:"+newFilter);
			
			selectColumn=filterJson.substring(projIndex+1).trim().substring(1).trim();
			System.out.println("--selectColumn:"+selectColumn);
			
			filterJson=newFilter;
		}
		
		System.out.println("--filter:"+filterJson);
		
		//if(pos<inputJson.length
		String others=inputJson.substring(pos+1,inputJson.length());
		System.out.println("--others:"+others);
		
		String limitPara = "";
		String sortPara = "";
		String skipPara = "";
				
		if(StringUtils.isNotBlank(others)) {
//		.limit(1).sort({"runtime":1}).skip(1)
		int limitIndex=StringTest4.getKeyPosition(others, "limit(");
		int sortIndex=StringTest4.getKeyPosition(others, "sort(");
		int skipIndex=StringTest4.getKeyPosition(others, "skip(");
		
		System.out.println("limitIndex: "+limitIndex);
		System.out.println("sortIndex: "+sortIndex);
		System.out.println("skipIndex: "+skipIndex);
		
		
		if(limitIndex>0)System.out.println("limitIndex subString: "+others.substring(limitIndex+6));
		if(sortIndex>0)System.out.println("sortIndex subString: "+others.substring(sortIndex+5));
		if(skipIndex>0)System.out.println("skipIndex subString: "+others.substring(skipIndex+5));
		
		
//		System.out.println("limitIndex subString: "+StringTest4.getKeyPosition(others.substring(limitIndex+6),")"));
//		System.out.println("sortIndex subString: "+StringTest4.getKeyPosition(others.substring(sortIndex+5),")"));
//		System.out.println("skipIndex subString: "+StringTest4.getKeyPosition(others.substring(skipIndex+5),")"));
		
		if(limitIndex>0) {
		String limitOthers=others.substring(limitIndex+6);
		limitPara=limitOthers.substring(0,StringTest4.getKeyPosition(limitOthers,")"));
		}
		
		if(sortIndex>0) {
		String sortOthers=others.substring(sortIndex+5);
		sortPara=sortOthers.substring(0,StringTest4.getKeyPosition(sortOthers,")"));
		}
		
		if(skipIndex>0) {
		String skipOthers=others.substring(skipIndex+5);
		skipPara=skipOthers.substring(0,StringTest4.getKeyPosition(skipOthers,")"));
		}
		
		System.out.println("limit para: "+limitPara);
		System.out.println("sort para: "+sortPara);
		System.out.println("skip para: "+skipPara);
		}
		
	      Document doc = new Document();
	      doc.append("find", tableName);
		
			if ("".equals(inputJson)){
				//empty
			}else{
				Document filter = Document.parse(filterJson);
				doc.append("filter", filter);
			
			
			  if(StringUtils.isNotBlank(selectColumn)) {
		          Document projection = Document.parse(selectColumn);
		          doc.append("projection", projection);	  
			  }
			
//			执行的顺序是先 sort(), 然后是 skip()，最后是显示的 limit()。
			if (StringUtils.isNotBlank(sortPara)) {
				Document sortDoc = Document.parse(sortPara);
				doc.append("sort", sortDoc);
			}
			
			if(StringUtils.isNotBlank(skipPara)) {
				doc.put("skip", Integer.parseInt(skipPara.trim()));
			}
			
			if(StringUtils.isNotBlank(limitPara)) {
				doc.put("limit", Integer.parseInt(limitPara.trim()));
			}
	}
			
		  System.out.println(doc.toJson());
	      Document result = getDb().runCommand(doc);
	      
		return result.toJson();
	}
	
	public String insert(String tableName,String inputJson) {
	      Document doc = new Document();
	      doc.append("insert", tableName);
		
	      
	      Map maps = (Map)JSON.parse(inputJson);
	      
	      Document jsonDoc = new Document(maps);
	      Document arrayDoc[]=new Document[1];
	      arrayDoc[0]=jsonDoc;
//	      doc.append("documents", arrayDoc);
	      doc.append("documents", "["+inputJson+"]");
	      
//	      System.out.println(doc.toJson());
	      
	      Document result = getDb().runCommand(doc);
	      
		return result.toJson();
	}

	private MongoDatabase getDb() {
		MongoClient mongoClient = null;
		MongoDatabase mongoDatabase = null;
		try {
			mongoClient = MongoClients.create("mongodb://localhost:27017");
			mongoDatabase = mongoClient.getDatabase("testa");
			
			
			
//	          CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(
//	                  MongoClientSettings.getDefaultCodecRegistry(),
//	                  CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));
//	          mongoDatabase.withCodecRegistry(pojoCodecRegistry);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
//	    	 if(mongoClient!=null) mongoClient.close();
		}

		return mongoDatabase;
	}

}
