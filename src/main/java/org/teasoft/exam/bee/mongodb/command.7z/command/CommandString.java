package org.teasoft.exam.bee.mongodb.command;

public class CommandString {
	
//	final static String find0 = "db.movies.find( { title: \"The Favourite\" } )";
//	final static String find0 = "db.movies.find ()";
//	final static String find0 = "db.movies.find({ \"title\": \"Jurassic }) aa\" } , { title: 1, type: 1, _id: 0,runtime:1 })";
	final static String find0 = "db.movies.find({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })";
//	final static String find0 = "db.movies.find( { \"title\": \"Tag\" } ).limit(1).sort({\"runtime\":1}).skip(2)";

//	final static String find1 = """
//			db.movies.find( { title: "The Favourite" } )
//			""";
	
	static String find1 =""
	+"db.movies.find( "
	+"{ title: \"The Favourite\" } )"
	+";";
	
	//字段用双引号
//	final static String find2 = """
//			db.movies.find( { "title": "Tag" } )  
//			""";
	
	final static String find2 = ""
			+"db.movies.find("
			+"{ \"title\": \"Tag\" }" 
			 
			+")"  
			;
	
	//in
	final static String find3 = """
	             db.movies.find( { rated: { $in: [ "PG", "PG-13" ] } } )
	             """;
	
	final static String find4 = """
	        db.movies.find( { countries: "Mexico", "imdb.rating": { $gte: 7 } } )			
            """;
	
//or里有：}, {  ，y
//	final static String find5 = """
//			db.movies.find( {
//     year: 2010,
//     $or: [ { "awards.wins": { $gte: 5 } }, { genres: "Drama" } ]
//} )
//            """;
	
	final static String find5 = """
	db.movies.find( {
year: 2010,
$or: [ { "awards.wins": { $gte: 5 } }, { genres: "Drama" } ]
} )
    """;
	
	final static String find6 = """
			db.movies.find( { "title": "Tag" } ).sort({"runtime":-1})
            """;
	
	final static String find7 = """
			db.movies.find({"title": "Tag"}).sort({"runtime":1}).skip(1).limit(1)
            """;
	
	//skip(), limilt(), sort()三个放在一起执行的时候，执行的顺序是先 sort(), 然后是 skip()，最后是显示的 limit()。
	//以下不按顺序写
final static String find8 = """
	db.movies.find( { "title": "Tag" } ).limit(1).sort({"runtime":1}).skip(1)	
""";

final static String find9 = """
db.movies.findOne( { _id: 123 } )
""";


final static String find10 = """
db.movies.find({ "title": "Tag" },{ title: 1, type: 1, _id: 0 })  
""";

//比5多选字段
final static String find11 = """
db.movies.find( {
year: 2018,
$or: [ { "runtime": { $gte: 115 } }, { genres: "Drama" } ]
} ,{ title: 1, type: 1, _id: 0,runtime:1 })
""";

final static String find12 = "db.movies.find ()";
final static String find13 = "db.movies.find ({})";

			
	final static String insertOne = """
		 db.movies.insertOne(
			  {
			    title: "The Favourite",
			    genres: [ "Drama", "History" ],
			    runtime: 121,
			    rated: "R",
			    year: 2018,
			    directors: [ "Yorgos Lanthimos" ],
			    cast: [ "Olivia Colman", "Emma Stone", "Rachel Weisz" ],
			    type: "movie"
			  }
			)
			  """;
	
//	final static String insertOne = """
//			 db.movies.insertOne(
//				  {
//				    title: "The Favourite",
//				    runtime: 121,
//				    rated: "R",
//				    year: 2018,
//				    type: "movie"
//				  }
//				)
//				  """;
	
	final static String insertMany = """
			db.movies.insertMany([
			                      {
			                         title: "Jurassic World: Fallen Kingdom",
			                         genres: [ "Action", "Sci-Fi","Drama" ],
			                         runtime: 130,
			                         rated: "PG-13",
			                         year: 2018,
			                         directors: [ "J. A. Bayona" ],
			                         cast: [ "Chris Pratt", "Bryce Dallas Howard", "Rafe Spall" ],
			                         type: "movie"
			                       },
			                       {
			                         title: "Tag",
			                         genres: [ "Comedy", "Action" ],
			                         runtime: 105,
			                         rated: "R",
			                         year: 2018,
			                         directors: [ "Jeff Tomsic" ],
			                         cast: [ "Annabelle Wallis", "Jeremy Renner", "Jon Hamm" ],
			                         type: "movie"
			                       }
			                   ])
			""";
	
	
	
	

	
	
	
	final static String updateOne = """
			db.movies.updateOne( { title: "Tag" },
				{
				  $set: {
				    plot: "One month every year, five highly competitive friends hit the ground running for a no-holds-barred game of tag"
				  }
				  { $currentDate: { lastUpdated: true } }
				})
				            """;

	final static String updateMany = """
			db.listingsAndReviews.updateMany(
				  { security_deposit: { $lt: 100 } },
				  {
				    $set: { security_deposit: 100, minimum_nights: 1 }
				  }
				)
				            """;
	
	
	
	final static String replaceOne = """
			db.accounts.replaceOne(
			  { account_id: 371138 },
			  { account_id: 893421, limit: 5000, products: [ "Investment", "Brokerage" ] }
			)
			            """;

	

//deleteAll
final static String deleteAll = """
		db.movies.deleteMany({})
""";

final static String deleteMany = """
		db.movies.deleteMany( { title: "The Favourite" } )
""";

final static String deleteOne = """
		db.movies.deleteOne( { cast: "Brad Pitt" } )
""";

final static String deleteOne_2 = """
db.inventory.deleteOne( { _id: 809393675304961 } )
""";

final static String deleteOne_3 = """
db.movies.deleteOne( { title: "aa" } )
""";

final static String deleteOne_4 = """
db.movies.deleteOne( { title: "The Favourite" } )
""";


//https://www.runoob.com/mongodb/mongodb-remove.html
final static String delete_Old = """
db.movies.remove( { title: "aa" } )
""";
//https://www.runoob.com/mongodb/mongodb-remove.html
final static String deleteAll_Old = """
db.col.remove({})
""";



final static String insertMany21 = """
db.inventory.insertMany( [
                          { item: "canvas", qty: 100, size: { h: 28, w: 35.5, uom: "cm" }, status: "A" },
                          { item: "journal", qty: 25, size: { h: 14, w: 21, uom: "cm" }, status: "A" },
                          { item: "mat", qty: 85, size: { h: 27.9, w: 35.5, uom: "cm" }, status: "A" },
                          { item: "mousepad", qty: 25, size: { h: 19, w: 22.85, uom: "cm" }, status: "P" },
                          { item: "notebook", qty: 50, size: { h: 8.5, w: 11, uom: "in" }, status: "P" },
                          { item: "paper", qty: 100, size: { h: 8.5, w: 11, uom: "in" }, status: "D" },
                          { item: "planner", qty: 75, size: { h: 22.85, w: 30, uom: "cm" }, status: "D" },
                          { item: "postcard", qty: 45, size: { h: 10, w: 15.25, uom: "cm" }, status: "A" },
                          { item: "sketchbook", qty: 80, size: { h: 14, w: 21, uom: "cm" }, status: "A" },
                          { item: "sketch pad", qty: 95, size: { h: 22.85, w: 30.5, uom: "cm" }, status: "A" }
                       ] );
""";

final static String updateOne21 = """
db.inventory.updateOne(
		   { item: "paper" },
		   {
		     $set: { "size.uom": "cm", status: "P" },
		     $currentDate: { lastModified: true }
		   }
		)
""";

final static String updateMany21 = """
db.inventory.updateMany(
		   { "qty": { $lt: 50 } },
		   {
		     $set: { "size.uom": "in", status: "P" },
		     $currentDate: { lastModified: true }
		   }
		)
""";

final static String replaceOne21 = """
db.inventory.replaceOne(
		   { item: "paper" },
		   { item: "paper", instock: [ { warehouse: "A", qty: 60 }, { warehouse: "B", qty: 40 } ] }
		)
""";

final static String save21 = """
db.inventory.save(
		   { item: "paper" },
		   { item: "paper", instock: [ { warehouse: "A", qty: 82 }, { warehouse: "B", qty: 40 } ] }
		)
""";

final static String deleteAll21 = """
db.inventory.deleteMany({})
""";


}
