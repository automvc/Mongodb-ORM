package org.teasoft.exam.bee.mongodb.command;

public class StringTest {
	
	public static void main(String[] args) {
		String str="({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })";
		
//		StringBuffer sb=new StringBuffer(str);
		
		char[] array=str.toCharArray();
		int len=array.length;
		for (int i = 0; i < array.length; i++) {
//			System.out.println(array[i]);
			if(array[i]=='}' && len>i+1 && array[i+1]==')'){
				System.out.println(i);
			}
		}
	}

}
