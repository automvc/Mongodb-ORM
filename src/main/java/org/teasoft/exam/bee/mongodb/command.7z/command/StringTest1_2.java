package org.teasoft.exam.bee.mongodb.command;
import java.util.Iterator;

import org.teasoft.honey.util.StringUtils;

public class StringTest1_2 {

	public static void main(String[] args) {
//		String str = "({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })";
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok
//		String str = "({ \"title\": \'Jurassic }) aa\'";//ok  //在引号内跳过
		
//		String str = "( { \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok
		String str = "( { \"title\": \"Tag\" } ).limit(1).sort({\"runtime\":1}).skip(1)";//ok
//		String str = "(a {( { \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok
//		String str = "(a {( { \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok  多个开头
		
//		String str = " ( {'age':{$gte:34},'age':{$lte:60}} )"; //有多个条件
		
		str=str.trim();
		int pos=getEndPosition(str);
		System.out.println(pos);
		System.out.println(str.substring(1,pos).trim());
		
		
//		int oldLen=str.length();
//		
//		str=str.substring(1,str.length());
//		str.substring(1)
		
	
	}
	
// 查找{(开头，} )结束的结束下标位置。两个标识之间可以有空格。
   public static int getEndPosition(String str) {
	    str=str.trim();
		char[] array = str.toCharArray();
		int len = array.length;
		boolean isStart = false;

		int single = -1;
		int dou = -1;

//		boolean hasFirst=false; //找到第一个符号
//		boolean hasSecond=false; //找到第一个符号
		
		for (int i = 0; i < len; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'') {
				single *= -1;
				continue;
			}else if (array[i] == '\"') {
				dou *= -1;
				continue;
			}else if (!(single == -1 && dou == -1)) { //在引号内跳过
				continue;
			}

			if (!isStart && array[i] == '(') {
				for (int k = i+1; k < len; k++) {
					if(array[k] == '{') {
						isStart = true;
						i=k;
						break;
					}else if(array[k] == ' ' || array[k] == '\t' || array[k] == '\n') {
						continue;
					}else {
						isStart=false;
						i=k;
						break;
					}
				} //end for k
				
				if(isStart) continue; //首次查到后返回
			}
			if (isStart) {
//				if (array[i] == '}') {
//					hasFirst=true;
//				}else {
//					if (array[i] == ' ') continue;
//					else if(hasFirst && array[i] == ')') {
//						hasSecond=true;
////						return i;
//						System.out.println(i);
//					}else {
//						hasFirst= false;
//					}
//				}
				
//				if (array[i] == '}' && len > i + 1 && array[i + 1] == ')'
//						&& (single == -1 && dou == -1)
//						) {
//					System.out.println(i);
//				}
				
				if (array[i] == '}') {
					for (int k = i+1; k < len; k++) {
						if(array[k] == ')') {
							i=k;
//							System.out.println(i);
//							break;
							return k;
						}else if(array[k] == ' ' || array[k] == '\t' || array[k] == '\n') {
							continue;
						}else {
//							i=k;
							break;
						}
					} //end for k
				}
				
				
			}
		}//end for
		
		return -1;
   }
   
   
   public static int getKeyPosition(String str,String key) {
	   if(StringUtils.isBlank(str) || StringUtils.isBlank(key)) return -1;
	   
		char[] array = str.toCharArray();
		int len = array.length;
//		boolean isStart = false;
		
		char[] keyChar=key.toCharArray();

		int single = -1;
		int dou = -1;
	   
		for (int i = 0; i < len; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'') {
				single *= -1;
				continue;
			}else if (array[i] == '\"') {
				dou *= -1;
				continue;
			}else if (!(single == -1 && dou == -1)) { //在引号内跳过
				continue;
			}
			
			if(array[i] == keyChar[0]) {
			   if(keyChar.length==1) return i;
			   for (int k = 1; k < keyChar.length; k++) {
				   if(array[i+k] == keyChar[k]) {
					   if(k+1==keyChar.length) return i;
					   continue;
				   }else {
//					   i=k-1;  //for 还有i++
					   break;
				   }
			   }
			}
		}
	   
	   return -1;

   }
   
   //返回key结束的位置； key之间可以有空陋
   public static int getKeyEndPosition(String str,String key) {
	   if(StringUtils.isBlank(str) || StringUtils.isBlank(key)) return -1;
	   
	    int r=-1;
	   
		char[] array = str.toCharArray();
		int len = array.length;
//		boolean isStart = false;
		
		char[] keyChar=key.toCharArray();

		int single = -1;
		int dou = -1;
	   
		for (int i = 0; i < len; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'') {
				single *= -1;
				continue;
			}else if (array[i] == '\"') {
				dou *= -1;
				continue;
			}else if (!(single == -1 && dou == -1)) { //在引号内跳过
				continue;
			}
			
			if(array[i] == keyChar[0]) {
				r=i;
			   if(keyChar.length==1) return r;
			   for (int k = 1; k < keyChar.length; k++) {
				   while(i+k<len && array[i+k]==' '|| array[k] == '\t' || array[k] == '\n') i++;
				   if(i+k<len && array[i+k] == keyChar[k]) {
//					   if(k+1==keyChar.length) return i+k;
					   if(k+1==keyChar.length) return r;
					   continue;
				   }else {
					   break;
				   }
			   }
			}
		}
	   
	   return -1;

   }
   
   
   //开始是{,  找对应的};  在字符串里的不算入
    static int getKeyEndPosition2(String str,char start,char end) {
	   if(StringUtils.isBlank(str)) return -1;
		char[] array = str.toCharArray();
		int len = array.length;
//		boolean isStart = false;
		
//		char[] keyChar=key.toCharArray();

		int single = -1;
		int dou = -1;
		
		int startCount=-1;  //计数遇到的开始标识,在引号里的不计
	   
		for (int i = 0; i < len; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'') {
				single *= -1;
				continue;
			}else if (array[i] == '\"') {
				dou *= -1;
				continue;
			}else if (!(single == -1 && dou == -1)) { //在引号内跳过
				continue;
			}
			
			if(array[i] == start) {
				startCount++;
				continue;
			}
			if(array[i] == end) {
				startCount--;
				if(startCount==-1) return i;
			}
		}
	   return -1;
   }

}
