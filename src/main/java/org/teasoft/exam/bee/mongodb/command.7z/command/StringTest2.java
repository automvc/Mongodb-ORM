package org.teasoft.exam.bee.mongodb.command;
public class StringTest2 {

	
	public static void main(String[] args) {
//		String str = "({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })";
		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )"; //寻找的字符，中间有空隔则不行。

//		StringBuffer sb=new StringBuffer(str);

		char[] array = str.toCharArray();
		int len = array.length;
		boolean isStart = false;

		int single = -1;
		int dou = -1;

		for (int i = 0; i < array.length; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'')
				single *= -1;
			if (array[i] == '\"')
				dou *= -1;

			if (!isStart && array[i] == '(' && len > i + 1 && array[i + 1] == '{') {
				isStart = true;
			}
			if (isStart) {
				if (array[i] == '}' && len > i + 1 && array[i + 1] == ')'
						&& (single == -1 && dou == -1)
						) {
					System.out.println(i);
				}
			}
		}
	}

}
