package org.teasoft.exam.bee.mongodb.command;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;


/**
 * 此文是解析 shell用的命令，转成 API的语法
 * 难点是解析
 * @author ctc
 * @since  1.0
 */
public class ParseCommand10 {
	
	public static void main(String[] args) throws Exception{
		 MongoClient mongoClient=null;
	      try{   
	          mongoClient =MongoClients.create("mongodb://localhost:27017");
	          MongoDatabase mongoDatabase = mongoClient.getDatabase("testa");  
	         
	         
//	         db.getCollection('student').find()  //没有参数的，解析不了。
	         
//	                         客户端两种都可以
//	         db.student2.find();
//	         db.getCollection('student2').find()  //ok
	         
//	        String json= mongodbCommandFind(mongoDatabase, "db.getCollection('student2').find({'age':{$gt:1}})"); //ok
//	        String json= mongodbCommandFind(mongoDatabase, "db.getCollection('student').find({'age':{$gt:20}})"); //可以查多条 //ok
//	        String json= mongodbCommandFind(mongoDatabase, "db.getCollection('student').find({'age':{$gte:34}})"); //可以查多条//ok
//	        String json= mongodbCommandFind(mongoDatabase, "db.getCollection('student').find({'age':{$gte:34},'age':{$lte:60}})"); //可以查多条//ok
//	         String json= mongodbCommandFind(mongoDatabase, "db.getCollection('student').find()");
	        
	        
//	         String queryGt="db.getCollection('laAppInterface').find({'invokeType':{$gt:1}},{'appCode':1,'invokeType':1, 'Type':0})";
	        
//	         String queryGt="db.movies.find({ \"title\": \"Tag\" },{ title: 1, type: 1, _id: 0 })";
//	         String queryGt="db.getCollection('movies').find({ \"title\": \"Tag\" },{ title: 1, type: 1})";
	         String queryGt="db.getCollection('movies').find({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })";
//	         String queryGt="db.getCollection('movies').find({'runtime':{$gt:115}},{ title: 1, type: 1, _id: 0,runtime:1 }).sort({\"runtime\":-1})";
	         String json= mongodbCommandFind(mongoDatabase,queryGt);
	        
	        System.out.println(json);
	         
	      }catch(Exception e){
	    	  e.printStackTrace();
//		         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		      }finally {
		    	 if(mongoClient!=null) mongoClient.close();
		      }
	}
	
	public static String mongodbCommandFind(MongoDatabase mongoDatabase, String queryGt ) throws Exception {
//      String queryGt="db.getCollection('laAppInterface').find({'invokeType':{$gt:1}},{'appCode':1,'invokeType':1, 'Type':0})";
      String queryReg = ".+\\.find\\(\\{(.+)\\}\\).*";  //用".find("分隔, 前面至少有一个字符
      boolean isMatch = Pattern.matches(queryReg, queryGt);
      if (!isMatch)
          throw new Exception("此接口仅执行查询语句，且需要制定查询条件");
      String tableRegExp = "getCollection\\('(\\w+?)'\\)";   //获取集合名
//      String queryRegExp = "\\.find\\((.*?)\\)";  //获取查询条件
//      String columnNameRegExp = "'(\\w+?)':1";
      String table = GetWithRegExps(queryGt, tableRegExp).get(0);
//      String query = GetWithRegExps(queryGt, queryRegExp).get(0);
      
      String query="{ \"title\": 'Jurassic }) aa' } ,{ title: 1, type: 1, _id: 0,runtime:1 }";
      System.out.println("query:"+query);
//      String search = query.split("\\},")[0] + "}";
      String search = query.split("\\},")[0] ;
      
      System.out.println("query after: "+query);
      
       
      Document doc = new Document();
      doc.append("find", table);
      search += "}";
      if(isMatch) {
    	  
      if (query.split("\\},").length > 1) {
          String selectColumn = query.split("\\},")[1];
          System.out.println("selectColumn: "+selectColumn);
//          List<String> columnNames = GetWithRegExps(show, columnNameRegExp);
          Document projection = Document.parse(selectColumn);
//          for (int i = 0; i < columnNames.size(); i++)
//              projection.put(columnNames.get(i), 1);
          doc.append("projection", projection);
      }
      System.out.println("filter:"+search);
      Document filter = Document.parse(search);
      doc.append("filter", filter);
      
      
      }
      
      System.out.println("findJson: "+doc.toJson());
      
      Document result = mongoDatabase.runCommand(doc);
      
		Set<Map.Entry<String, Object>> set = result.entrySet();
		for (Entry<String, Object> entry : set) {
			System.out.print(entry.getKey());
			System.out.println("  ,  "+entry.getValue().getClass().getName());
		}
      
      return result.toJson();
  }
  private static List<String> GetWithRegExps(String s, String regExp) {
      List<String> ss = new ArrayList<String>();
      Pattern r = Pattern.compile(regExp);
      
      System.out.println(s);
      
      // 现在创建 matcher 对象
      Matcher m = r.matcher(s);
      while (m.find()) {
    	  System.out.println(m.group(0));
    	  System.out.println(m.group(1));
          ss.add(m.group(1));
      }
      return ss;
  }

}
