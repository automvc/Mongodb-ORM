package org.teasoft.exam.bee.mongodb.command;
public class StringTest3 {

	public static void main(String[] args) {
//		String str = "({ \"title\": \"Jurassic }) aa\" },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })"; //ok
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 })";
//		String str = "({ \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok
//		String str = "({ \"title\": \'Jurassic }) aa\'";//ok  //在引号内跳过
		
//		String str = "( { \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok
		String str = "(a {( { \"title\": \'Jurassic }) aa\' },{ title: 1, type: 1, _id: 0,runtime:1 } )";//ok


		char[] array = str.toCharArray();
		int len = array.length;
		boolean isStart = false;

		int single = -1;
		int dou = -1;

//		boolean hasFirst=false; //找到第一个符号
//		boolean hasSecond=false; //找到第一个符号
		for (int i = 0; i < len; i++) {
//			System.out.println(array[i]);
			if (array[i] == '\'') {
				single *= -1;
				continue;
			}else if (array[i] == '\"') {
				dou *= -1;
				continue;
			}else if (!(single == -1 && dou == -1)) { //在引号内跳过
				continue;
			}

			if (!isStart && array[i] == '(') {
				for (int k = i+1; k < len; k++) {
					if(array[k] == '{') {
						isStart = true;
						i=k;
						break;
					}else if(array[k] == ' ') {
						continue;
					}else {
						isStart=false;
						i=k;
						break;
					}
				} //end for k
			}
			if (isStart) {
//				if (array[i] == '}') {
//					hasFirst=true;
//				}else {
//					if (array[i] == ' ') continue;
//					else if(hasFirst && array[i] == ')') {
//						hasSecond=true;
////						return i;
//						System.out.println(i);
//					}else {
//						hasFirst= false;
//					}
//				}
				
//				if (array[i] == '}' && len > i + 1 && array[i + 1] == ')'
//						&& (single == -1 && dou == -1)
//						) {
//					System.out.println(i);
//				}
				
				if (array[i] == '}') {
					for (int k = i+1; k < len; k++) {
						if(array[k] == ')') {
							i=k;
							System.out.println(i);
							break;
						}else if(array[k] == ' ') {
							continue;
						}else {
							i=k;
							break;
						}
					} //end for k
				}
				
				
			}
		}//end for
	}

}
