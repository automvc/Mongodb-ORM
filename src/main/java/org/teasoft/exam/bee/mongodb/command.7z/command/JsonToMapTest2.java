package org.teasoft.exam.bee.mongodb.command;
//package org.teasoft.beex.mongodb.command;
//
//import java.util.Map;
//
//import com.alibaba.fastjson.JSON;  
//import com.alibaba.fastjson.JSONObject;  
//import java.util.Map;  
//
//public class JsonToMapTest2 {
//	
//	public static void main(String[] args) {
//		 String str = """
//		 		[{"0":"zhangsan","1":"lisi","2":"wangwu","3":"maliu"}]
//		 				 """;  
////	        //第一种方式  
//	        Map maps = (Map)JSON.parse(str);  
//	        System.out.println("这个是用JSON类来解析JSON字符串!!!");  
//	        for (Object map : maps.entrySet()){  
//	            System.out.println(((Map.Entry)map).getKey()+"     " + ((Map.Entry)map).getValue());  
//	        }  
//////	原文链接：https://blog.csdn.net/m0_54866636/article/details/123643002
//		
////		
////		  Map json = (Map) JSONObject.parse(str);  
////	        System.out.println("这个是用JSONObject类的parse方法来解析JSON字符串!!!");  
////	        for (Object map : json.entrySet()){  
////	            System.out.println(((Map.Entry)map).getKey()+"  "+((Map.Entry)map).getValue());  
////	        }  
//	}
//
//}
